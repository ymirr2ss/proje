﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ders26
{
    public partial class AnaEkranForm : Form
    {
        public AnaEkranForm()
        {
            InitializeComponent();
        }
        public Sinema cinema = new Sinema();
        private void btnFimIslemleri_Click(object sender, EventArgs e)
        {
            FilmIsmlerForm filmislemleriformu = new FilmIsmlerForm();
            filmislemleriformu.Show();
            this.Hide();
        }

        private void AnaEkranForm_Load(object sender, EventArgs e)
        {

        }
    }
}
