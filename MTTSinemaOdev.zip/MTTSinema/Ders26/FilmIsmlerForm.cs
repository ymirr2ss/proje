﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ders26
{
    public partial class FilmIsmlerForm : Form
    {

        public FilmIsmlerForm()
        {
            InitializeComponent();
        }
        AnaEkranForm anaekran = (AnaEkranForm)Application.OpenForms["AnaEkranForm"];
        Film film;
        void filmleriListele()
        {
            listViewFilmler.Items.Clear();
            List<Film> gelenListe = anaekran.cinema.filmListesiGonder();

            for(int i = 0; i < gelenListe.Count; i++)
            {
                listViewFilmler.Items.Add(gelenListe[i].FilmId);
                listViewFilmler.Items[i].SubItems.Add(gelenListe[i].FilmAdi);
                listViewFilmler.Items[i].SubItems.Add(gelenListe[i].FilmTuru);
                listViewFilmler.Items[i].SubItems.Add(gelenListe[i].FilmSuresi.ToString());
                listViewFilmler.Items[i].SubItems.Add(gelenListe[i].FilmUcreti.ToString());
            }
        }
        private void btnEkle_Click(object sender, EventArgs e)
        {
            string filmAdi = txtFilmAdi.Text;
            string filmTuru = cBoxFilmTur.Text;
            int filmSuresi = int.Parse(txtFilmSuresi.Text);
            int filmUcreti=int.Parse(txtFilmUcreti.Text);
            film=new Film(filmAdi, filmTuru, filmSuresi, filmUcreti);
            film.FilmIdver();

            
            if(anaekran.cinema.filmEkle(film))
            {
                MessageBox.Show("Film Başarıyla Eklendi.");
                filmleriListele();
            }
            else
            {
                MessageBox.Show("Aynı isimli film daha önce eklenmiştir.");
            }

        }

        private void FilmIsmlerForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            anaekran.Show();
            this.Dispose();

        }

        private void FilmIsmlerForm_Load(object sender, EventArgs e)
        {
            filmleriListele();
        }
    }
}
