﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders26
{
    public class Sinema
    {
        List<Film> filmlerListesi=new List<Film>();

        public bool filmEkle(Film film)
        {

            if (filmAra(film.FilmAdi) == false)
            {
                filmlerListesi.Add(film);
                return true;
            }
            else
                return false;
                
         
            
        }

        public List<Film> filmListesiGonder()
        {
            return filmlerListesi;
        }

        bool filmAra(string ad)
        {
            foreach(Film film in filmlerListesi)
            {
                if(film.FilmAdi==ad)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
