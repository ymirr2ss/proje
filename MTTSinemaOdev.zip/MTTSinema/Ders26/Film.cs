﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ders26
{
    public class Film
    {
        string filmId, filmAdi, filmTuru;
        int filmSuresi, filmUcreti;

        public string FilmId { get { return filmId; } }
        public string FilmAdi { get => filmAdi; set => filmAdi = value; }
        public string FilmTuru { get => filmTuru; set => filmTuru = value; }
        public int FilmSuresi
        {
            get => filmSuresi;
            set
            {
                if (value < 30)
                    throw new Exception("Film Süresi 30 dakikadan az olamaz.");
                else
                    filmSuresi = value;
            }
        }
        public int FilmUcreti { get => filmUcreti; set => filmUcreti = value; }

        public Film()
        { }

        public Film(string filmAdi, string filmTuru, int filmSuresi, int filmUcreti)
        {
         
            FilmAdi = filmAdi;
            FilmTuru = filmTuru;
            FilmSuresi = filmSuresi;
            FilmUcreti = filmUcreti;
           
        }

        public void FilmIdver()
        {
            Random r = new Random();
            int idUret = r.Next(10000, 100000);
            filmId = idUret.ToString();
        }
    }
}
