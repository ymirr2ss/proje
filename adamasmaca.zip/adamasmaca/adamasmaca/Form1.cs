﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adamasmaca
{
    public partial class Form1 : Form
    {
        List<string> kelimeler = new List<string> { "ARABA", "TÜRKİYE", "TABLET", "BİTCOİN", "KAFA", "PARMAK", "BARDAK", "AŞK", "SEVGİ", "NESNE", "KURABİYE", "BİLGİSAYAR", "ET" };
        public Form1()
        {
            InitializeComponent();
        }
        public void sureayarla(string secilenkelime)
        {
            timer1.Interval = secilenkelime.Count()*100;
        }
        Random rand;
        int tahminsayi = 0;
        public string rastgelekelimesec()
        {
            rand = new Random();
            secilkel = kelimeler[rand.Next(0, kelimeler.Count())];
            tahminsayi = secilkel.Length;
            return secilkel;
        }
        public void harflerigizle(string secilenkelime)
        {
            for(int i = 0; i < secilenkelime.Length; i++)
            {
                label3.Text += "_";
            }
            
        }
        public void ilkhal()
        {
            Button[] butonlar = new Button[] {button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,button12,button13,button14,button15,button16,button17,button18,button19,button20,button21,button22,button23,button24,button25,button26,button27,button28};
            pictureBox1.Image = Image.FromFile("Resimler//1.png");
            foreach (Button button in butonlar) { button.Enabled = false; }
            progressBar1.Value = 0; progressBar1.Enabled = false; timer1.Enabled = false;
            textBox1.Enabled = false; button1.Enabled = true; button29.Enabled = false; label2.Text = "0"; label3.Text = ""; label4.Text = "";
        }
        public void ilkhal2()
        {
            Button[] butonlar = new Button[] { button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16, button17, button18, button19, button20, button21, button22, button23, button24, button25, button26, button27, button28 };
            pictureBox1.Image = Image.FromFile("Resimler//1.png");
            foreach (Button button in butonlar) { button.Enabled = true; }
            progressBar1.Value = 100; progressBar1.Enabled = true; timer1.Enabled = true;
            textBox1.Enabled = true; button1.Enabled = false; button29.Enabled = true; label2.Text = "0"; label3.Text = ""; label4.Text = "";
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (tahminsayi == 0) { timer1.Enabled = false; MessageBox.Show("Tebrikler Kelimeyi Buldunuz!"); ilkhal(); }
            else
            {
                progressBar1.Value -= 1;
                if (progressBar1.Value == 0) { MessageBox.Show("Başaramadın! Daha sonra beklerizz"); ilkhal(); }
            }
            
        }
        string secilkel ="";
        private void button1_Click(object sender, EventArgs e)
        {
            ilkhal2();
            rastgelekelimesec();
            harflerigizle(secilkel);
            sureayarla(secilkel);
        }
        Button button;
        int hata=1;
        private void button28_Click(object sender, EventArgs e)
        {
            button = new Button();
            button = sender as Button;
            button.Enabled = false;
            label4.Text += button.Text;
            if (secilkel.Contains(button.Text))
            {
                for (int i = 0; i < secilkel.Length; i++)
                {
                    if (button.Text[0] == secilkel[i])
                    {
                        label2.Text = (Convert.ToInt32(label2.Text) + 10).ToString();
                        label3.Text = label3.Text.Remove(i, 1);
                        label3.Text = label3.Text.Insert(i, button.Text);
                        tahminsayi--;
                    }

                }
            }
            else
            {
                hata++;
                pictureBox1.Image = Image.FromFile("Resimler//" + hata + ".png");
                if (hata == 7) { ilkhal(); MessageBox.Show("Malesef adamınız asıldı gg :D"); }
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            if (secilkel == textBox1.Text.Trim().ToUpper())
            {
                ilkhal();
                MessageBox.Show("Tebrikler KAZANDINIZ!");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
    }
}
