﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace listeOgrenci
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
        }

        public bool kontrol_no()
        {
            string numara = textBox1.Text.Trim();
            foreach (char c in numara)
            {
                if (!char.IsNumber(c))
                { return false; }
                else { return true; }
            }
            return false;
        }
        int ogrenciSayi = 0;
        public bool kontrol()
        {

            if (kontrol_no())
            {
                if (!string.IsNullOrEmpty(textBox1.Text) &&
               !string.IsNullOrEmpty(textBox2.Text) &&
               !string.IsNullOrEmpty(textBox3.Text) &&
               comboBox1.SelectedIndex != -1 &&
               !ogrenci.Contains(textBox1.Text.Trim()))
                { return true; }
                else { return false; }
            }
            else { return false; }
        }
        public void ekle()
        {
            kayitNo++;
            ogrenci.Add(kayitNo);
            ogrenci.Add(textBox1.Text.Trim());
            ogrenci.Add(textBox2.Text.Trim());
            ogrenci.Add(textBox3.Text.Trim());
            ogrenci.Add(comboBox1.SelectedItem.ToString().Trim());
            
        }

        public void goster()
        {
            
            label14.Text = kayitNo.ToString();
            
            label13.Text = ogrenci[indx].ToString();
            label12.Text = ogrenci[indx + 1].ToString();
            label11.Text = ogrenci[indx + 2].ToString();
            label10.Text = ogrenci[indx + 3].ToString();
        }
        public void sil()
        {
            if(kontrol_no())
            {
                indx_sil = ogrenci.IndexOf(textBox1.Text);
                for (int i = 0; i<4; i++)
                {
                    ogrenci.RemoveAt(indx_sil);
                }
            }
        }
        int indx_sil;
        public void guncalla()
        {
            indx = ogrenci.IndexOf(textBox1.Text);

            ogrenci[indx+1] = textBox2.Text;
            
            
            ogrenci[indx + 2] = textBox3.Text;
           

            ogrenci[indx + 3] = comboBox1.SelectedItem;
           
           
        }
        ArrayList ogrenci = new ArrayList();    
        private void button1_Click(object sender, EventArgs e)
        {
            if (kontrol())
            {
                ekle();
                ogrenciSayi++;
                label16.Text=ogrenciSayi.ToString();
            }
            else
                MessageBox.Show("Bilgileri Kontrol Ediniz..");
        }
        int indx,kayitNo=0;
        private void button2_Click(object sender, EventArgs e)
        {
            if(ogrenci.Contains(textBox1.Text.Trim()))
            {
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                textBox1.Enabled = false;
                indx = ogrenci.IndexOf(textBox1.Text);
                goster();
            }
            else
            { MessageBox.Show("Öğrenci bulunamadı."); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (kontrol_no())
            {
                if(ogrenci.Contains(textBox1.Text))
                {
                    sil();
                    ogrenciSayi--;
                    label14.Text = "";
                    label13.Text = "";
                    label12.Text = "";
                    label11.Text = "";
                    label10.Text = "";
                }
            }
        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            guncalla();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (kayitNo == (ogrenci.Count) % 5)
            {
                button8.Enabled = false;
                button9.Enabled = false;
            }
            else
            {
                indx = ogrenci.Count - 5;
                goster();
            }
        }
        
        private void button7_Click(object sender, EventArgs e)
        {
            if (kayitNo == 1)
            {
                button6.Enabled = false;
                button7.Enabled = false;
            }
            else
            {
                indx = ogrenci.Count + 5;
                goster();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
           
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = true;
                button9.Enabled = true;
                label14.Text = ogrenci[0].ToString();
                label13.Text = ogrenci[1].ToString();
                label12.Text = ogrenci[2].ToString();
                label11.Text = ogrenci[3].ToString();
                label10.Text = ogrenci[4].ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = false;
            button9.Enabled = false;
            int elemanSayisi = ogrenci.Count;
            label14.Text = ogrenci[elemanSayisi - 5].ToString();
            label13.Text = ogrenci[elemanSayisi - 4].ToString();
            label12.Text = ogrenci[elemanSayisi - 3].ToString();
            label11.Text = ogrenci[elemanSayisi - 2].ToString();
            label10.Text = ogrenci[elemanSayisi - 1].ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
        }
    }
}
