﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otobusFirma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public bool karakterKontrol()
        {
            foreach (char c in textBox1.Text.Trim())
            {
                if (!char.IsNumber(c))
                { return false; }
            }
            return true;
        }
        public string cinsiyet()
        {
            if (radioButton1.Checked == true)
            { return "Erkek"; }
            else if (radioButton2.Checked == true)
            { return "Kadın"; }
            return "        ";
        }
        public bool bosmuKontrol()
        {
            if (!string.IsNullOrEmpty(textBox1.Text) &&
                !string.IsNullOrEmpty(textBox2.Text) &&
                !string.IsNullOrEmpty(textBox3.Text) &&
                (radioButton1.Checked == true || radioButton2.Checked == true))
            {
                return true;
            }
            else return false;
        }
        List<Otobus> yolcuListesi = new List<Otobus>();
        List<string> oturaklar = new List<string>();
        List<string> koltukontrol = new List<string>();
        Otobus yolcuk;
        public void yolcuEkle()
        {
            yolcuk = new Otobus(Convert.ToUInt64(textBox1.Text), textBox2.Text, textBox3.Text, cinsiyet(), textBox4.Text);
            yolcuListesi.Add(yolcuk);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult cevap = MessageBox.Show("Bilet satışı yapılsın mı?", "Bilet Satış", MessageBoxButtons.YesNo);
            if (cevap == DialogResult.Yes)
            {
                if (bosmuKontrol() == true && karakterKontrol() == true)
                {
                    if (ortk != null)
                    {

                        yolcuEkle();
                        koltuk(); MessageBox.Show("Test");
                    }
                    else
                    {
                        MessageBox.Show("Seçim Yapınız.");
                    }
                }
                else
                    MessageBox.Show("Bilgileri hatasız giriniz.");
            }
            try
            {
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu! \n" );
            }
        }
        Button ortk;
        private void ortak(object sender, EventArgs e)
        {
            ortk = new Button();
            ortk = (Button)sender;
            textBox4.Text=ortk.Text;
        }        
        void koltuk()
        {
            if (oturaklar.Contains(ortk.Text.ToString()))
            {
                MessageBox.Show("Koltuk Dolu.");
            }
            else
            {
                try
                {
                    textBox4.Text = ortk.Text;
                    textBox5.Text = ortk.Text;
                }
                catch
                {
                    MessageBox.Show("Koltuk seçimi hatalı..");
                }
                if (cinsiyet() == "Erkek")
                { koltukontrol[Convert.ToInt32(ortk.Text)] = "Erkek"; ortk.BackColor = Color.PaleTurquoise; }
                else if (cinsiyet() == "Kadın")
                { koltukontrol[Convert.ToInt32(ortk.Text)] ="Kadın";
                    ortk.BackColor = Color.Pink; 
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult cevp = MessageBox.Show("Bilet iptalı yapılsın mı?", "Bilet İptali", MessageBoxButtons.YesNo);
            if (cevp == DialogResult.Yes)
            {
                if (ortk != null)
                {
                    if (oturaklar.Contains(ortk.Text))
                    {
                        oturaklar.Remove(ortk.Text);
                        ortk.BackColor = Color.White;
                    }
                    else
                    {
                        MessageBox.Show("Seçilen Koltuk Satışı Yapılmadı.");
                    }
                }
                else
                {
                    MessageBox.Show("Lütfen Seçim Yapınız..");
                }
            }
        }

        
        public bool erkekKadınKontrol()
        {
            int kntrll = Convert.ToInt32(ortk.Text);
            if (kntrll % 3 == 0)
            {
                if (koltukontrol[kntrll - 1] == "Erkek" && cinsiyet() == "Kadın")
                {
                    MessageBox.Show("Erkek kadın yan yana oturamaz.(Kadınlarımızı erkeklerden koruyoruz)");
                    return false;
                }
                else if (koltukontrol[kntrll - 1] == "Kadın" && cinsiyet() == "Erkek")
                {
                    MessageBox.Show("Erkek kadın yan yana oturamaz.(Kadınlarımızı erkeklerden koruyoruz)");
                    return false;
                }
                else return true;
            }
            else if (kntrll %3==2)
            {
                if (koltukontrol[kntrll + 1] == "Erkek" && cinsiyet() == "Kadın")
                {
                    MessageBox.Show("Erkek kadın yan yana oturamaz.(Kadınlarımızı erkeklerden koruyoruz)");
                    return false;
                }
                else if (koltukontrol[kntrll + 1] == "Kadın" && cinsiyet() == "Erkek")
                {
                    MessageBox.Show("Erkek kadın yan yana oturamaz.(Kadınlarımızı erkeklerden koruyoruz)");
                    return false;
                }
                else return true;
            }
            return false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 30; i ++)
            { koltukontrol.Add("bos"); }
        }
    }
}
