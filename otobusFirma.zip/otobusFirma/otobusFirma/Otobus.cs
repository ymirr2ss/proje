﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace otobusFirma
{
    internal class Otobus
    {
        ulong tc;
        string ad, soyad, cinsiyet, seciliKoltuk;
        public string _ad
        {get => ad; set=>ad = value;}
        public string _soyad
        { get => soyad; set => soyad = value; }
        public string _cinsiyet
        { get => cinsiyet; set => cinsiyet = value; }
        public string _seciliKoltuk
        { get => seciliKoltuk; set => seciliKoltuk = value;}
        public ulong _tc
        { get => tc; set => tc = value; }

        public Otobus(ulong tc,string ad,string soyad , string cinsiyet,string seciliKoltuk) 
        {
            this.tc = tc;
            this.ad = ad;
            this.soyad = soyad;
            this.cinsiyet= cinsiyet;
            this.seciliKoltuk= seciliKoltuk;
        }
    }
}
