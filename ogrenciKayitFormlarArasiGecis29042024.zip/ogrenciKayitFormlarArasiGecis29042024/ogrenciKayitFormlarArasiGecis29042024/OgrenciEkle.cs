﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogrenciKayitFormlarArasiGecis29042024
{
    public partial class OgrenciEkle : Form
    {
        
        public bool veriKontrol()
        {
            if (!string.IsNullOrEmpty(txtNo.Text) &&
                !string.IsNullOrEmpty(txtAd.Text) &&
                 !string.IsNullOrEmpty(txtSoyad.Text) &&
                (rbtnErkek.Checked || rbtnkadin.Checked) &&
                cmbDogumilce.SelectedIndex != -1 && cmbDogumYeri.SelectedIndex != -1)
            {
                return true;
            }
            else
                return false;
        }
        public OgrenciEkle()
        {
            InitializeComponent();
        }
        public void temizle()
        {
            txtNo.Text = string.Empty;
            txtAd.Text = string.Empty;
            txtSoyad.Text = string.Empty;
            dTDogumTarihi.Text = string.Empty;
            cmbDogumilce.SelectedIndex = -1;
            cmbDogumYeri.SelectedIndex = -1;
            rbtnErkek.Checked = false;
            rbtnkadin.Checked = false;
        }
        void ogrenciOlustur()
        {
            string no = txtNo.Text;
            string ad = txtAd.Text;
            string soyad = txtSoyad.Text;
            string cinsiyet;
            if (rbtnErkek.Checked)
                cinsiyet = rbtnErkek.Text;
            else
                cinsiyet = rbtnkadin.Text;
            string dogumTarihi = dTDogumTarihi.Text;
            string dogumYeri = cmbDogumYeri.Text;
            string dogumilce = cmbDogumilce.Text;
            mttOgrencisi = new Ogrenci(no, ad, soyad, cinsiyet, dogumilce, dogumTarihi, dogumYeri);
            mttOgrencisi.ogrenciNoVer(no);
        }

        private void OgrenciEkle_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
            Application.OpenForms["anaForm"].Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Application.OpenForms["anaForm"].Show();
        }

        Ogrenci mttOgrencisi;
        private void button1_Click(object sender, EventArgs e)
        {
            if(veriKontrol())
            {
                ogrenciOlustur();

                anaForm anaform = (anaForm)Application.OpenForms["anaForm"];

                if(anaform.mttMtal.ogrenciEkle(mttOgrencisi))
                {
                    MessageBox.Show("Öğrenci Başarıyla Eklendi.");
                    temizle(); 
                }
                else
                {
                    MessageBox.Show("Ekleme Sırasında Hata Oluştu.");
                    temizle();
                }
            }
            else
            {
                MessageBox.Show("Lütfen Verileri Kontrol Ediniz.","HATA!",MessageBoxButtons.OK);
            }
                


        }

        private void cmbDogumilce_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbDogumYeri_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dTDogumTarihi_ValueChanged(object sender, EventArgs e)
        {

        }

        private void rbtnkadin_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnErkek_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtSoyad_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAd_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
