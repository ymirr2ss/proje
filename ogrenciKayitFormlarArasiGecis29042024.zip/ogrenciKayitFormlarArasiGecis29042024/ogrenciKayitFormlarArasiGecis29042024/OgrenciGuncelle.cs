﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogrenciKayitFormlarArasiGecis29042024
{
    public partial class OgrenciGuncelle : Form
    {
        public OgrenciGuncelle()
        {
            InitializeComponent();
        }
        void temizle()
        {
            txtAd.Text = string.Empty;
            txtSoyad.Text = string.Empty;
            rbtnkadin.Checked = false;
            rbtnErkek.Checked = false;
            dTDogumTarihi.Checked = false;
            cmbDogumYeri.SelectedIndex = -1;
            cmbDogumilce.SelectedIndex = -1;
        }
        
        void guncelle()
        {
            try
            {
                geleneleman.Ad = txtAd.Text;
                geleneleman.Soyad = txtSoyad.Text;
                if (rbtnkadin.Checked == true)
                { geleneleman.Cinsiyet = "Kadın"; }
                else { geleneleman.Cinsiyet = "Erkek"; }
                geleneleman.DogumYeri = cmbDogumYeri.SelectedItem.ToString();
                geleneleman.Dogumilcesi = cmbDogumilce.SelectedItem.ToString();
                geleneleman.Dogumtarihi = dTDogumTarihi.Text;
                MessageBox.Show("Güncelleme işlemi başarılı.", "BİLGİ", MessageBoxButtons.OK);
            }
            catch
            {
                MessageBox.Show("Güncelleme işlemi başarısız.", "HATA!", MessageBoxButtons.OK);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            guncelle();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Application.OpenForms["anaForm"].Show();
        }

        private void OgrenciGuncelle_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
            Application.OpenForms["anaForm"].Show();
        }
        Ogrenci geleneleman;
        Okul okul = new Okul();
        anaForm anaform = (anaForm)Application.OpenForms["anaForm"];
        private void button3_Click(object sender, EventArgs e)
        {
            geleneleman = anaform.mttMtal.ogrenciAra(textBox1.Text);
            if(geleneleman != null)
            {
                groupBox1.Enabled = true;

                textBox1.Text = geleneleman.No.ToString();
                txtAd.Text = geleneleman.Ad.ToString();
                txtSoyad.Text = geleneleman.Soyad.ToString();
                if (geleneleman.Cinsiyet == "Kadın")
                { rbtnkadin.Checked = true; }
                else { rbtnErkek.Checked = true; }
                dTDogumTarihi.Text = geleneleman.Dogumtarihi;
                cmbDogumilce.SelectedItem = geleneleman.Dogumilcesi;
                cmbDogumYeri.SelectedItem = geleneleman.DogumYeri;
            }
            else 
            {
                groupBox1.Enabled=false;
            }
          
            
        }
    }
}
