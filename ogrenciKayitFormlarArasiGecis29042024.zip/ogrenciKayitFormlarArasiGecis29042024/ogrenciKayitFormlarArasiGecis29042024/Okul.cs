﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ogrenciKayitFormlarArasiGecis29042024
{
    public class Okul
    {
        public List<Ogrenci> ogrenciListesi = new List<Ogrenci>();

        public bool ogrenciEkle(Ogrenci ogr)
        {
            try
            {
                if (ogrenciVarMi(ogr))
                {
                    throw new Exception("Aynı öğrenci bulunmaktadır.");
                }
                else
                {
                    ogrenciListesi.Add(ogr);
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
        
        public bool ogrenciVarMi(Ogrenci ogr)
        {
            foreach(Ogrenci ogrenci in ogrenciListesi)
            {
                if (ogrenci.No == ogr.No)
                {
                    return true;
                }
            }
            return false;
        }
        public bool sil(string no)
        {
            foreach (Ogrenci eleman in ogrenciListesi)
            {
                if (eleman.No == no)
                {
                    ogrenciListesi.Remove(eleman);
                    return true;
                }
            }
            return false;
        }
        public Ogrenci ogrenciAra(string no)
        {
            foreach (Ogrenci eleman in ogrenciListesi)
            {
                if (eleman.No==no)
                {
                    return eleman;
                }
            }
            return null;
        }
        
        public List<Ogrenci> listegonder()
        { return ogrenciListesi; }
    }
}