﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ogrenciKayitFormlarArasiGecis29042024
{
    public class Ogrenci
    {
        string no, ad, soyad, cinsiyet, dogumYeri, dogumilcesi, dogumtarihi;

        public string No { get { return no; } set { no = value; } }
        public string Ad { get { return ad; } set { ad = value; } }
        public string Soyad { get { return soyad; } set { soyad = value; } }
        public string Cinsiyet { get { return cinsiyet; } set { cinsiyet = value; } }
        public string Dogumilcesi { get { return dogumilcesi; } set => dogumilcesi = value; }
        public string Dogumtarihi { get { return dogumtarihi; } set { dogumtarihi = value; } }
        public string DogumYeri { get { return dogumYeri; } set => dogumYeri = value; }

        public Ogrenci(string no, string ad, string soyad, string cinsiyet, string dogumilcesi, string dogumtarihi, string dogumYeri)
        {
            No = no;
            Ad = ad;
            Soyad = soyad;
            Cinsiyet = cinsiyet;
            Dogumilcesi = dogumilcesi;
            Dogumtarihi = dogumtarihi;
            DogumYeri = dogumYeri;
        }
        public Ogrenci() { }

        public void ogrenciNoVer(string numara)
        {
            no = numara;
        }
    }
}
