﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace ogrenciKayitFormlarArasiGecis29042024
{
    public partial class OgrenciAra : Form
    {
        public OgrenciAra()
        {
            InitializeComponent();
        }
        
        private void OgrenciAra_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
            Application.OpenForms["anaForm"].Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Application.OpenForms["anaForm"].Show();
        }
        Ogrenci geleneleman;
       
        private void button4_Click(object sender, EventArgs e)
        {
            
            anaForm anaekran = (anaForm)Application.OpenForms["anaForm"];
            string noo = txtNo.Text;
            geleneleman = anaekran.mttMtal.ogrenciAra(noo);
            if (anaekran.mttMtal.ogrenciAra (noo) != null)
            {
                geleneleman = anaekran.mttMtal.ogrenciAra(txtNo.Text);
                txtAd.Text = geleneleman.Ad;
                txtSoyad.Text = geleneleman.Soyad;
                if (geleneleman.Cinsiyet == "Kadın")
                { rbtnkadin.Checked = true; }
                else { rbtnErkek.Checked = true; }
                dTDogumTarihi.Text = geleneleman.Dogumtarihi;
                cmbDogumilce.SelectedItem = geleneleman.Dogumilcesi;
                cmbDogumYeri.SelectedItem = geleneleman.DogumYeri;

            }
            
            else
            {
                
                MessageBox.Show("Girilen numara ile öğrenci bulunmamakta.");
                txtNo.Text = string.Empty;
                txtAd.Text = string.Empty;
                txtSoyad.Text = string.Empty;
                dTDogumTarihi.Text = string.Empty;
                cmbDogumilce.SelectedIndex = -1;
                cmbDogumYeri.SelectedIndex = -1;
                rbtnErkek.Checked = false;
                rbtnkadin.Checked = false;
            }
        }
    }
}
