﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogrenciKayitFormlarArasiGecis29042024
{
    public partial class OgrenciListele : Form
    {
        public OgrenciListele()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Application.OpenForms["anaForm"].Show();
        }
        
        

        private void OgrenciListele_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
            Application.OpenForms["anaForm"].Show();
        }
        List<Ogrenci> gelenliste;
        anaForm anafrm = (anaForm)Application.OpenForms["anaForm"];
        private void OgrenciListele_Load(object sender, EventArgs e)
        {

            gelenliste = anafrm.mttMtal.listegonder();
            for(int i = 0;i<gelenliste.Count;i++)
            {
                listBox1.Items.Add(gelenliste[i].No);
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text=gelenliste[listBox1.SelectedIndex].No;
            textBox2.Text=gelenliste[listBox1.SelectedIndex].Ad;
            textBox3.Text=gelenliste[listBox1.SelectedIndex].Soyad;
            textBox4.Text=gelenliste[listBox1.SelectedIndex].Cinsiyet;
            textBox5.Text=gelenliste[listBox1.SelectedIndex].Dogumtarihi;
            textBox6.Text=gelenliste[listBox1.SelectedIndex].DogumYeri;
            textBox7.Text=gelenliste[listBox1.SelectedIndex].Dogumilcesi;
        }
    }
}
