﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogrenciKayitFormlarArasiGecis29042024
{
    public partial class anaForm : Form
    {
        
        
        public anaForm()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            OgrenciEkle ogrEkle = new OgrenciEkle();
            ogrEkle.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OgrenciSil ogrSil = new OgrenciSil();
            ogrSil.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OgrenciGuncelle ogrGuncelle = new OgrenciGuncelle();
            ogrGuncelle.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OgrenciListele ogrListele = new OgrenciListele();
            ogrListele.Show();
            this.Hide();
        }
        
        private void button5_Click(object sender, EventArgs e)
        {
            OgrenciAra ogrAra = new OgrenciAra();
            ogrAra.Show();
            this.Hide();
        }
        public Okul mttMtal = new Okul();
        private void anaForm_Load(object sender, EventArgs e)
        {

        }
    }
}
