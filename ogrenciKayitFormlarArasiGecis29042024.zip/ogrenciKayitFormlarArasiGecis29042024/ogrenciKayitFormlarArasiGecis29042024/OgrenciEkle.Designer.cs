﻿namespace ogrenciKayitFormlarArasiGecis29042024
{
    partial class OgrenciEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNo = new System.Windows.Forms.TextBox();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.rbtnErkek = new System.Windows.Forms.RadioButton();
            this.rbtnkadin = new System.Windows.Forms.RadioButton();
            this.dTDogumTarihi = new System.Windows.Forms.DateTimePicker();
            this.cmbDogumYeri = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbDogumilce = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ad :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Soyad :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "No :";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Cinsiyet :";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Doğum Tarihi :";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "Doğum Yeri :";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtNo
            // 
            this.txtNo.Location = new System.Drawing.Point(111, 6);
            this.txtNo.Name = "txtNo";
            this.txtNo.Size = new System.Drawing.Size(100, 22);
            this.txtNo.TabIndex = 1;
            this.txtNo.TextChanged += new System.EventHandler(this.txtNo_TextChanged);
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(111, 34);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(100, 22);
            this.txtAd.TabIndex = 1;
            this.txtAd.TextChanged += new System.EventHandler(this.txtAd_TextChanged);
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(111, 61);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(100, 22);
            this.txtSoyad.TabIndex = 1;
            this.txtSoyad.TextChanged += new System.EventHandler(this.txtSoyad_TextChanged);
            // 
            // rbtnErkek
            // 
            this.rbtnErkek.AutoSize = true;
            this.rbtnErkek.Location = new System.Drawing.Point(111, 90);
            this.rbtnErkek.Name = "rbtnErkek";
            this.rbtnErkek.Size = new System.Drawing.Size(63, 20);
            this.rbtnErkek.TabIndex = 2;
            this.rbtnErkek.TabStop = true;
            this.rbtnErkek.Text = "Erkek";
            this.rbtnErkek.UseVisualStyleBackColor = true;
            this.rbtnErkek.CheckedChanged += new System.EventHandler(this.rbtnErkek_CheckedChanged);
            // 
            // rbtnkadin
            // 
            this.rbtnkadin.AutoSize = true;
            this.rbtnkadin.Location = new System.Drawing.Point(180, 89);
            this.rbtnkadin.Name = "rbtnkadin";
            this.rbtnkadin.Size = new System.Drawing.Size(62, 20);
            this.rbtnkadin.TabIndex = 2;
            this.rbtnkadin.TabStop = true;
            this.rbtnkadin.Text = "Kadın";
            this.rbtnkadin.UseVisualStyleBackColor = true;
            this.rbtnkadin.CheckedChanged += new System.EventHandler(this.rbtnkadin_CheckedChanged);
            // 
            // dTDogumTarihi
            // 
            this.dTDogumTarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTDogumTarihi.Location = new System.Drawing.Point(111, 119);
            this.dTDogumTarihi.Name = "dTDogumTarihi";
            this.dTDogumTarihi.Size = new System.Drawing.Size(123, 22);
            this.dTDogumTarihi.TabIndex = 3;
            this.dTDogumTarihi.ValueChanged += new System.EventHandler(this.dTDogumTarihi_ValueChanged);
            // 
            // cmbDogumYeri
            // 
            this.cmbDogumYeri.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDogumYeri.FormattingEnabled = true;
            this.cmbDogumYeri.Items.AddRange(new object[] {
            "KOCAELİ",
            "BURSA",
            "İSTANBUL",
            "SAKARYA"});
            this.cmbDogumYeri.Location = new System.Drawing.Point(111, 146);
            this.cmbDogumYeri.Name = "cmbDogumYeri";
            this.cmbDogumYeri.Size = new System.Drawing.Size(121, 24);
            this.cmbDogumYeri.TabIndex = 4;
            this.cmbDogumYeri.SelectedIndexChanged += new System.EventHandler(this.cmbDogumYeri_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 185);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Doğum İlçesi  :";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // cmbDogumilce
            // 
            this.cmbDogumilce.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDogumilce.FormattingEnabled = true;
            this.cmbDogumilce.Items.AddRange(new object[] {
            "GEBZE",
            "DARICA",
            "ÇAYIROVA",
            "İZMİT",
            "DERİNCE",
            "KÖRFEZ"});
            this.cmbDogumilce.Location = new System.Drawing.Point(111, 176);
            this.cmbDogumilce.Name = "cmbDogumilce";
            this.cmbDogumilce.Size = new System.Drawing.Size(121, 24);
            this.cmbDogumilce.TabIndex = 4;
            this.cmbDogumilce.SelectedIndexChanged += new System.EventHandler(this.cmbDogumilce_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(98, 217);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 30);
            this.button1.TabIndex = 5;
            this.button1.Text = "EKLE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(245, 240);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(64, 31);
            this.button2.TabIndex = 6;
            this.button2.Text = "Geri";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // OgrenciEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 283);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmbDogumilce);
            this.Controls.Add(this.cmbDogumYeri);
            this.Controls.Add(this.dTDogumTarihi);
            this.Controls.Add(this.rbtnkadin);
            this.Controls.Add(this.rbtnErkek);
            this.Controls.Add(this.txtSoyad);
            this.Controls.Add(this.txtAd);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtNo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "OgrenciEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Öğrenci Ekle";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OgrenciEkle_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNo;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.RadioButton rbtnErkek;
        private System.Windows.Forms.RadioButton rbtnkadin;
        private System.Windows.Forms.DateTimePicker dTDogumTarihi;
        private System.Windows.Forms.ComboBox cmbDogumYeri;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbDogumilce;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}